import 'package:flutter/material.dart';
import '../Model/Product.dart';
class ProductDetails extends StatefulWidget {
  final Product product;
  const ProductDetails({super.key, required this.product});

  @override
  State<ProductDetails> createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  Color selectedColor =Colors.transparent;
 // ProductVariation v1 =ProductVariation(id: id, productId: productId, price: price, quantity: quantity, inStock: inStock, productVarientImages: productVarientImages)
  String? selectedSize;
  List<String> currentImages = [];

  String  currentLogourl="";
  num ?price;
  num ?originalPrice=900;

  @override
  void initState() {
    super.initState();
    currentLogourl = widget.product.brandLogoUrl;
    if (widget.product.variations.isNotEmpty) {
      price = widget.product.variations[0].price;
    }
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.grey.shade900,
        appBar: AppBar(
            leading: BackButton(
              color: Colors.white,
              onPressed: () {
                Navigator.pop(context);},
            ),
            backgroundColor: Colors.grey.shade900,
            elevation: 0,
            title: const Center(
                child: Text("Chosen Product Details", style: TextStyle(color: Colors.white)))),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(

              children: [

              Center(
                 child:Image.network(
                    currentLogourl,
                    width: 200,
                    height: 200,

                ),
              ),
              const Divider(
                color: Colors.grey,
                thickness: 1,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: widget.product.variations.map((variation) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 80,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: variation.productVarientImages.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: (){
                                setState(() {
                                  currentLogourl = variation.productVarientImages[index];
                                });
                              },
                              child: Image.network(
                                variation.productVarientImages[index],
                                width: 100,
                                height: 100,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20
                      ),
                      Wrap(
                        spacing: 5,
                        runSpacing: 5,
                        children: currentImages.map((imageUrl) {
                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                currentLogourl = imageUrl;
                              });
                            },
                            child: Image.network(
                              imageUrl,
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          );
                        }).toList(),
                      ),
                      const Divider(color: Colors.grey),
                      Text(
                        " id: ${widget.product.id}",
                        style: const TextStyle(color: Colors.white, fontSize: 20),
                      ),
                      // Text(
                      //   'Variation ID: ${variation.id}',
                      //   style: const TextStyle(color: Colors.white, fontSize: 18),
                      // ),
                      const SizedBox(height: 15),
                      Text(
                        'Quantity: ${variation.quantity}',
                        style: const TextStyle(color: Colors.white, fontSize: 18),
                      ),
                      const SizedBox(height: 15),
                      Text(
                        'Price: \$$price',
                        style: const TextStyle(color: Colors.white, fontSize: 18),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Text(
                        "Name:  ${widget.product.name}",
                        style: const TextStyle(color: Colors.white, fontSize: 20),
                      ),

                    ],
                  );
                }).toList(),
              ),

                  const SizedBox(
                    width: 60,
                  ),

              Row(
                children: widget.product.availableProperties.map((property) {
                  return Row(
                    children: property.colorImageMap.keys.map((color) {
                      return GestureDetector(
                         // List<Color> keys = colorImageMap.keys.tolist();                          return GestureDetector(
                          onTap: () {
                          setState(() {
                                selectedColor = color;
                                currentImages = List<String>.from(property.colorImageMap[color]!);
                          });
                          }, child: Container(
                            width: 30,
                          height: 30,
                            margin: const EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selectedColor == color ? Colors.black : Colors.transparent,
                          width: 2.0,
                          ),),),);
                          },
                          ).toList(),
                          );}).toList(),),

              const SizedBox(
                height: 10,
              ),
              Row(

                children: widget.product.availableProperties.map((property) {
                  return Row(
                    children: List.generate(property.Sizes.length,(index) {

                      final String size = property.Sizes[index];
                      return GestureDetector(
                        onTap: () {

                          setState(() {
                            selectedSize = size;
                            if(selectedSize=='50x50'){ //should check on product id also
                              price=900;
                              print(price);

                            }//Update the current color
                            else if( selectedSize=='150x150'){
                              price=1000;

                            }
                            else if( selectedSize=='L'){
                              price=990;
                            }
                            else if( selectedSize=='XL'){
                              price=1200;
                            }
                            else{
                            // Revert to the original price when no size option is selected
                            price = originalPrice;

                            }
                          });
                        }, child:Container(
                        height: 60,
                        width: 60,
                      alignment: Alignment.center,
                        margin: const EdgeInsets.symmetric(horizontal: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                           borderRadius: BorderRadius.circular(30),
                               boxShadow: [
                                BoxShadow(
                                   color: Colors.grey.withOpacity(0.5),
                                   spreadRadius: 3,
                                   blurRadius: 5,
                              ),
                              ]),
                           child: Text(
                             property.Sizes[index],
                             style: const TextStyle(
                             fontSize: 15,
                             color: Colors.black,
                            ),
                          ),
                         ),
                    );
                    }).toList(),
                  );
                }).toList(),),
              SizedBox(
                width: 350,
                child: ExpansionTile(
                  title: const Text("Description",
                      style: TextStyle(color: Colors.white, fontSize: 20)),
                  children: [
                    Text(
                      widget.product.description,
                      style: const TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ],
                ),
              ),
            ],
            ),
             )
            ),

            )
      );

  }
}
