import 'package:flutter/material.dart';

import '../Model/Product.dart';
import '../Model/ProductVariation.dart';
import '../Model/ProductPropertyAndValue.dart';
import '../Widgets/product_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  List<Product> products = [
  Product(
      id: 1,
      name: "Blosom Scarf",
      description: "Soft linen scarf, very comfy and colorful",
      brandId: 2100,
      brandName: "Emma",
      brandLogoUrl: "https://youremma.com/wp-content/uploads/2018/08/persian-queen-site-1.jpg?v=fbe46383db39",
      rating: 5.0,
      variations: [
        ProductVariation(
          productId: 1,
          id: 11 ,
          quantity: 10,
          price: 900,
          inStock: true,
          productVarientImages: [
            'https://youremma.com/wp-content/uploads/2018/08/persian-queen-site-10.jpg?v=fbe46383db39',
            'https://youremma.com/wp-content/uploads/2018/08/persian-queen-site-2.jpg?v=fbe46383db39',
            'https://youremma.com/wp-content/uploads/2018/08/persian-queen-site-7.jpg?v=fbe46383db39',
          ],
        ),
        ],
        availableProperties:[
          ProductProperty(
            Sizes: [
               'one Size'
          ], colorImageMap: {
            Colors.black:['https://youremma.com/wp-content/uploads/2023/02/DSC_4742.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2023/02/DSC_4632.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2023/02/DSC_4821.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2023/02/DSC_4822.jpg?v=fbe46383db39'],
           // Colors.blue :['https://youremma.com/wp-content/uploads/2022/06/DSC_0616.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2022/06/DSC_7889.jpg','https://youremma.com/wp-content/uploads/2022/06/DSC_7863.jpg?v=fbe46383db39']


          },
          )

        ]

  ),
    Product(
        id: 2,
        name: "Grey Elegance Scarf",
        description: "Elegant basic scarf, very comfy",
        brandId: 2300,
        brandName: "Emma",
        brandLogoUrl:
        "https://youremma.com/wp-content/uploads/2021/04/DSC_8476.jpg?v=fbe46383db39",
        rating: 4.0,
        variations: [
          ProductVariation(
            productId: 2,
            id: 22 ,
            quantity: 8,
            price: 950,
            inStock: true,
            productVarientImages: [
              'https://youremma.com/wp-content/uploads/2020/02/DSC_0368.jpg?v=fbe46383db39',
              'https://youremma.com/wp-content/uploads/2021/04/DSC_8490.jpg?v=fbe46383db39',
              'https://youremma.com/wp-content/uploads/2021/04/DSC_8445.jpg?v=fbe46383db39',
              'https://youremma.com/wp-content/uploads/2021/04/DSC04953-1.jpg?v=fbe46383db39',
            ],
          )
        ],
        availableProperties:[
          ProductProperty(

            Sizes: [
              '50x50',
              '150x150',
            ], colorImageMap: {
            Colors.black:['https://youremma.com/wp-content/uploads/2020/12/DSC_6850.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2020/12/DSC_6774.jpg?v=fbe46383db39'],
            Colors.blue :['https://youremma.com/wp-content/uploads/2022/06/DSC_0616.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2022/06/DSC_7889.jpg','https://youremma.com/wp-content/uploads/2022/06/DSC_7863.jpg?v=fbe46383db39'],
            Colors.green :['https://youremma.com/wp-content/uploads/2020/02/DSC_0570.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2021/04/DSC04835-1.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2021/04/DSC04827.jpg?v=fbe46383db39'],
            Colors.indigoAccent:['https://youremma.com/wp-content/uploads/2020/02/DSC_0540.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2021/04/DSC_8807.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2021/04/DSC05185-2.jpg?v=fbe46383db39'],
          },
          )
        ]
    ),
    Product(
        id: 3,
        name: "Galaxy Luna Scarf",
        description: "Elegant basic scarf, very stylish and inspiring",
        brandId: 2200,
        brandName: "Emma",
        brandLogoUrl: "https://youremma.com/wp-content/uploads/2019/05/ABU47267-38-1.jpg?v=fbe46383db39",
        rating: 4.5,
        variations: [
          ProductVariation(
            productId: 3,
            id: 33 ,
            quantity: 9,
            price: 950,
            inStock: true,
            productVarientImages: [
              'https://youremma.com/wp-content/uploads/2019/05/DSC00249-Copy.jpg?v=fbe46383db39',
              'https://youremma.com/wp-content/uploads/2019/05/Copy-of-DSC_5205.jpg?v=fbe46383db39',
              'https://youremma.com/wp-content/uploads/2019/05/Copy-of-DSC_5200.jpg?v=fbe46383db39',
            ],
          )
        ],
        availableProperties:[
          ProductProperty(

            Sizes: [
              '50x50',
              '150x150',
            ], colorImageMap: {


          },
          )
        ]
    ),

    Product(
      id: 4,
      name: "Latte Marble Scarf",
      description: "Elegant basic scarf, very comfy and colorful",
      brandId: 2300,
      brandName: "Emma",
      brandLogoUrl: "https://youremma.com/wp-content/uploads/2022/11/DSC_8982.jpg?v=fbe46383db39",
      rating: 4.0,
        variations: [
          ProductVariation(
            productId: 4,
            id: 44 ,
            quantity: 9,
            price: 950,
            inStock: true,
            productVarientImages: ['https://youremma.com/wp-content/uploads/2022/11/DSC_9011.jpg?v=fbe46383db39',
            ],
          )
        ],
        availableProperties:[
          ProductProperty(
            Sizes: [
              'L',
              'XL',
            ], colorImageMap: {
              Colors.lightBlueAccent:['https://youremma.com/wp-content/uploads/2023/02/DSC_4697.jpg.webp','https://youremma.com/wp-content/uploads/2023/02/DSC_4877.jpg?v=fbe46383db39','https://youremma.com/wp-content/uploads/2023/02/DSC_4710.jpg?v=fbe46383db39']

          },
          )
        ]
    ),

   ];

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        leading: const BackButton(color: Colors.white),
          backgroundColor: Colors.grey.shade900,
          elevation: 0,
          centerTitle: true,
          title: const Text("Slash Store App", style: TextStyle(color: Colors.white))),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Wrap(
                spacing: 5,
                runSpacing: 5,
                children: products.map((p) => shop_widget(product: p,)).toList(),
              ),
            ),
          ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigator.of(context).push(MaterialPageRoute(
          //   builder: (context) =>
          //   ),
          // ));
        },
        backgroundColor: Colors.white,
        child: const Icon(
          Icons.shopping_cart,
          color: Colors.deepOrange,
        ),
      ),
    );

  }
}
