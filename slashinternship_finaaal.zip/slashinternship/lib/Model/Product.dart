
import 'ProductPropertyAndValue.dart';
import 'ProductVariation.dart';

class Product{

   int id;
   String name;
   String description;
   int brandId;
   String? brandName;
   String brandLogoUrl;
   double rating;
   List<ProductVariation> variations;
   List<ProductProperty> availableProperties; //What properties are offered //(multiple colors or non, multiple sizes or non, materials)
   Product({
     required this.id,
     required this.name,
     required this.description,
     required this.brandId,
     required this.brandName,
     required this.brandLogoUrl,
     required this.rating,
     required this.variations,
     required this.availableProperties,
   });



}