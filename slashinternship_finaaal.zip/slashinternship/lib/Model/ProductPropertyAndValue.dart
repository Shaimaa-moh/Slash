import 'dart:ui';

class ProductProperty {

   Map<Color, List<String>> colorImageMap = {};    //if property is color, value may be: #008000(hex for Green)
   // if property is size, value may be: XL
   List <String> Sizes =[];
   ProductProperty({
      required this.colorImageMap,
      required this.Sizes,
});


}
