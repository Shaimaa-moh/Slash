class ProductVariation {
   int id;
   int productId;
   num price;
   int quantity;
   bool inStock;  //to enable/disable addToCart button
   List<String> productVarientImages;

   ProductVariation({
     required this.id,
     required this.productId,
     required this.price,
     required this.quantity,
     required this.inStock,
     required this.productVarientImages,
   });


}
