class CartItem {
  int? id;
  late int productVariationId;
  late int quantity;   //user can add one or multiple items of the same product variation at once
}
