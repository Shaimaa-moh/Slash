import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:slashinternship/Screens/ProductDetails.dart';
import '../Model/Product.dart';



class shop_widget extends StatefulWidget {
  Product product;
  shop_widget({
    Key? key, required this.product,}) : super(key: key);
  @override
  State<shop_widget> createState() => _shop_widgetState();
}

class _shop_widgetState extends State<shop_widget> {
  @override
  Widget build(BuildContext context) {
    var rating = 0.0;
    return GestureDetector(
      onTap: (){
        Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => ProductDetails(product: widget.product,)));
        },
      child: Card(
          elevation: 3,
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
                height: 250,
                width: 145,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: Image.network(
                        widget.product.brandLogoUrl,
                        height: 140,
                        width: 140,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(widget.product.name,
                        style: const TextStyle(color: Colors.black, fontSize: 16)),
                    RatingBarIndicator(
                      rating: widget.product.rating,
                      itemCount: 5,
                      itemSize: 15.0,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, _) => const Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Brand: ${widget.product.brandName}",
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.black,
                          ),
                        ),
                        InkWell(
                          child: const Icon(
                            Icons.shopping_cart,
                            color: Colors.deepOrange,
                            size: 15,
                          ),
                          onTap: () {
                           // widget.product.add(widget.shop);
                          },
                        ),
                      ],
                    ),
                  ],
                )),
          ),

      ),
    );
  }
}
