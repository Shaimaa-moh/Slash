import 'package:flutter/material.dart';
import 'package:slashinternship/Screens/HomePage.dart';
import 'Model/Product.dart';


 void main() {

 Product product;

  runApp( MaterialApp(
    //home: widget_tree(),
    theme: ThemeData(
      scaffoldBackgroundColor: Colors.grey.shade900,
      colorScheme: const ColorScheme.dark(),
    ),
    initialRoute: '/',
    title: "Welcome to Slash store",
    routes:{
      "/":(context) =>const HomePage() , //landing page
      "/HomePage" :(context) =>const HomePage(),
      //"/ProductDetails" :(context) => ProductDetails(product: widget.product,),

    },
    debugShowCheckedModeBanner: false,
  ));
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Hello from Slash"),
        backgroundColor: Colors.indigo,

      ), // Use TripsListView here
    );
  }
}

