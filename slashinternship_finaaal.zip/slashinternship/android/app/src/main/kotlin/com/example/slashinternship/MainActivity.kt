package com.example.slashinternship

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
